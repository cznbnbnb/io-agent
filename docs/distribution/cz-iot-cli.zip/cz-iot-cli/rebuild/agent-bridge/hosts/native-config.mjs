import fs from 'node:fs';
import path from 'node:path';
import {BridgeError,readPrivateJson} from '../client.mjs';
import {runtimeDigest} from '../runtime-events.mjs';
import {directoryRoute,directoryLabel} from '../session-directory.mjs';
import {NativeRuntimeAdapter} from './native-runtime.mjs';
import {AcpSession} from './acp-session.mjs';
import {CodexDesktopSharedHost} from './codex-desktop-shared.mjs';
import {CodexAppServerSession} from './codex-app-server.mjs';
import {createClaudeModBroker} from './claude-mod/broker.mjs';

const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const need=(v,code='INVALID_NATIVE_CONFIG')=>{if(!v)throw new BridgeError(code,{permanent:true});};
const hostCapabilities=Object.freeze({atomic_idle_start:false,atomic_queue_append:true,atomic_queued_resume:true,exact_turn_interrupt:true,exact_turn_child_stop:true,final_result_evidence:true,native_queue_expiry:false});

/** Explicit, local host binding. No session discovery, creation, model launch,
 * or global plugin installation. Codex joins the loaded owner's event stream
 * without settings overrides. A disconnected native endpoint is
 * not retried behind the user's back: restart the bridge to reconnect. */
export function createNativeBridgeAdapter(config,{configDirectory,clock=Date.now,
  connectCodex=(id,options)=>CodexAppServerSession.connect(id,options),
  createClaudeBroker=createClaudeModBroker,connectAcp=options=>AcpSession.connect(options),connectDesktop=options=>CodexDesktopSharedHost.connect(options)}={}){
  const native=config.native_runtime;
  need(path.isAbsolute(configDirectory??'')&&object(native)&&config.adapter_command===undefined);
  need(Object.keys(native).every(k=>['state_file','sessions'].includes(k))&&typeof native.state_file==='string'&&native.state_file&&
    Array.isArray(native.sessions)&&native.sessions.length>0&&native.sessions.length<=32);
  const resolve=v=>path.resolve(configDirectory,v);
  const stateFile=resolve(native.state_file),keys=new Set(),directories=new Set();
  const entries=native.sessions.map(s=>{
    need(object(s)&&Object.keys(s).every(k=>['host_kind','workspace','route','label','endpoint','rpc_path','auth_file','broker_directory','acp','desktop'].includes(k))&&
      ['codex','claude','acp'].includes(s.host_kind)&&typeof s.workspace==='string'&&s.workspace&&directoryRoute(s.route)&&
      s.route.computer_id===config.computer_id&&s.route.agent_id===config.agent_id);
    const label=typeof s.label==='string'?s.label.trim():s.label;
    need(label===undefined||typeof s.label==='string'&&!/[\u0000-\u001f\u007f]/.test(s.label)&&directoryLabel(label));
    const key=runtimeDigest(s.route);need(!keys.has(key));keys.add(key);
    let workspace;try{workspace=fs.realpathSync(resolve(s.workspace));need(fs.statSync(workspace).isDirectory());}catch{need(false);}
    const binding={server_id:config.server_id,owner_id:config.owner_id,host_kind:s.host_kind,workspace,route:structuredClone(s.route)};
    if(s.desktop!==undefined){
      need(s.host_kind==='codex'&&object(s.desktop)&&Object.keys(s.desktop).sort().join()==='session_id,state_file'&&
        typeof s.desktop.session_id==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(s.desktop.session_id)&&typeof s.desktop.state_file==='string'&&s.desktop.state_file&&
        ['endpoint','rpc_path','auth_file','broker_directory','acp'].every(k=>s[k]===undefined));
      return{binding,label,desktop:{sessionId:s.desktop.session_id,stateFile:resolve(s.desktop.state_file)}};
    }
    if(s.acp!==undefined){
      need(object(s.acp)&&Object.keys(s.acp).sort().join()==='command,session_id,state_file'&&
        Array.isArray(s.acp.command)&&s.acp.command.length>0&&s.acp.command.every(v=>typeof v==='string'&&!/[\0\r\n]/.test(v))&&path.isAbsolute(s.acp.command[0])&&
        (s.acp.session_id===null||typeof s.acp.session_id==='string'&&s.acp.session_id&&s.acp.session_id.length<=256)&&typeof s.acp.state_file==='string'&&s.acp.state_file&&
        ['endpoint','rpc_path','auth_file','broker_directory'].every(k=>s[k]===undefined));
      return{binding,label,acp:{command:s.acp.command,sessionId:s.acp.session_id??undefined,stateFile:resolve(s.acp.state_file)}};
    }
    need(s.host_kind!=='acp');
    if(s.host_kind==='codex'){
      need(typeof s.endpoint==='string'&&s.endpoint&&s.broker_directory===undefined&&
        (s.auth_file===undefined||typeof s.auth_file==='string'&&s.auth_file));
      // Check transport syntax without touching a socket or reading a secret.
      let url;try{url=new URL(s.endpoint);}catch{need(false);}
      need(!url.username&&!url.password&&!url.hash&&!url.search&&
        (url.protocol==='unix:'&&!url.hostname&&path.isAbsolute(url.pathname)&&url.pathname!=='/'&&s.auth_file===undefined||
         url.protocol==='ws:'&&['127.0.0.1','[::1]'].includes(url.hostname)&&url.port));
      need(s.rpc_path===undefined||typeof s.rpc_path==='string'&&/^\/(?:[A-Za-z0-9._~-]+\/?)*$/.test(s.rpc_path),'INVALID_NATIVE_CONFIG');
      return{binding,label,endpoint:s.endpoint,rpcPath:s.rpc_path,authFile:s.auth_file?resolve(s.auth_file):null};
    }
    need(typeof s.broker_directory==='string'&&s.broker_directory&&s.endpoint===undefined&&s.auth_file===undefined);
    const directory=resolve(s.broker_directory);need(!directories.has(directory));directories.add(directory);
    return{binding,label,directory};
  });
  let runtime=null,closers=[],bindings=[];
  const adapter={
    name:'native-session-runtime',
    routeBindingDigest:runtimeDigest(entries.map(e=>e.binding).sort((a,b)=>runtimeDigest(a.route).localeCompare(runtimeDigest(b.route)))),
    capabilities:{can_execute:true,async_events:true,admission_probe_v1:true,control_intake_probe_v1:true,task_session_control_v1:true},
    acceptsRoute:route=>entries.some(e=>runtimeDigest(e.binding.route)===runtimeDigest(route)),
    async start(){
      need(!runtime&&!closers.length,'NATIVE_CONFIG_ALREADY_STARTED');bindings=[];
      try{
        for(const e of entries){
          let host;
          if(e.desktop){
            host=await connectDesktop({...e.desktop,workspace:e.binding.workspace,conversationId:e.binding.route.session_id,connectorDirectory:configDirectory,glasses:{bridge:{...config,native_runtime:undefined},route:e.binding.route}});
            closers.push(()=>host.close());
          }else if(e.acp){
            host=await connectAcp({...e.acp,workspace:e.binding.workspace,conversationId:e.binding.route.session_id,permissionMode:'phone',...(fs.existsSync(path.join(configDirectory,'connector.json'))?{connectorDirectory:configDirectory,glasses:{bridge:{...config,native_runtime:undefined},route:e.binding.route}}:{})});
            closers.push(()=>host.close());
          }else if(e.binding.host_kind==='codex'){
            let attempt=null,connectedHost=null;
            const get=()=>attempt??=(async()=>{
              let bearerToken;
              if(e.authFile){const auth=readPrivateJson(e.authFile);need(object(auth)&&Object.keys(auth).length===1&&typeof auth.token==='string'&&auth.token,'INVALID_NATIVE_AUTH');bearerToken=auth.token;}
              connectedHost=await connectCodex(e.binding.route.session_id,{endpoint:e.endpoint,workspace:e.binding.workspace,metadataOnly:true,subscribeEvents:true,...(e.rpcPath?{rpcPath:e.rpcPath}:{}),...(bearerToken?{bearerToken}:{})});
              return connectedHost;
            })();
            host={conversationId:e.binding.route.session_id,capabilities:hostCapabilities};
            host.lifecycle=()=>connectedHost?.lifecycle?.()??{closed:false};
            for(const method of ['status','start','startQueued','inspectOperation','interrupt','stopChildren','inspectStop','readiness','activitySnapshot'])host[method]=async(...args)=>{
              const connected=await get();need(typeof connected[method]==='function','NATIVE_RUNTIME_READINESS_UNSUPPORTED');return connected[method](...args);
            };
            closers.push(async()=>{if(attempt)try{await (await attempt).close();}catch{}});
          }else{
            const broker=await createClaudeBroker({directory:e.directory,binding:e.binding,clock});
            host=broker.host;
            // The Mod broker's status reads only the exact bound plugin's
            // local heartbeat. On load its conservative busy=true has no
            // turn identity yet; do not present that as observed active work.
            host.readiness=async()=>{
              const status=await broker.host.status();
              return{conversationId:status.conversationId,workspace:status.workspace,
                busy:status.busy===true&&!status.activeTurnId?null:status.busy,
                canExecute:true,reason:status.busy===true&&!status.activeTurnId?'CLAUDE_MOD_BUSY_UNKNOWN':null};
            };
            closers.push(()=>broker.close());
          }
          // Display metadata is not part of the durable task/route identity.
          bindings.push({binding:e.binding,label:e.label,host});
        }
        runtime=new NativeRuntimeAdapter({stateFile,bindings,clock});await runtime.start();return adapter.capabilities;
      }catch(error){await adapter.stop();throw error;}
    },
    lifecycle(){return bindings.map(({host})=>host.lifecycle?.()).find(s=>s?.closed||s?.reason==='transport_closed')??{closed:false};},
    async stop(){
      let failure;try{await runtime?.stop();}catch(error){failure=error;}
      for(const close of closers.reverse())try{await close();}catch(error){failure??=error;}
      runtime=null;closers=[];bindings=[];if(failure)throw failure;
    }
  };
  for(const method of ['onItem','onAnswer','onRequestClosed','inspectAdmission','inspectControlIntake','pollEvents','acknowledgeEvents','readinessSnapshot','pendingObservedTasks'])
    adapter[method]=(...args)=>{need(runtime,'NATIVE_CONFIG_NOT_STARTED');return runtime[method](...args);};
  return adapter;
}
